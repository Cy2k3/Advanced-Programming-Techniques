﻿namespace WpfApp1
{
    public static class ClipboardHelper
    {
        public static Student? CopiedStudent { get; set; }
    }
}