﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using WpfApp1;

namespace WpfApp1
{
    public class Student : INotifyPropertyChanged
    {
        private string? _name = null!; // Nullable with null-forgiving operator
        public string? Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<Course> Courses { get; } = new ObservableCollection<Course>();

        public string? CoursesString => string.Join(", ", Courses?.Select(c => c.Name) ?? Enumerable.Empty<string>());

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string name = null!)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public Student()
        {
            Courses.CollectionChanged += (s, e) => OnPropertyChanged(nameof(CoursesString));
        }
    }
}