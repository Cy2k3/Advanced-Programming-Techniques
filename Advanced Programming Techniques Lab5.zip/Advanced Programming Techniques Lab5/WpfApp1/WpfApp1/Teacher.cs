﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using WpfApp1;

namespace WpfApp1
{
    public class Teacher : INotifyPropertyChanged
    {
        private string? _name = null!;
        public string? Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<Course> TaughtCourses { get; } = new ObservableCollection<Course>();

        public string? CoursesString => string.Join(", ", TaughtCourses.Select(c => c.Name));

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string name = null!)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public Teacher()
        {
            TaughtCourses.CollectionChanged += (s, e) => OnPropertyChanged(nameof(CoursesString));
        }
    }
}