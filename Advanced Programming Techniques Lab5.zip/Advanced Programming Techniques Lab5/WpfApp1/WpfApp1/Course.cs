﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Linq;

namespace WpfApp1
{
    public class Course : INotifyPropertyChanged
    {
        private string? _name = null!;
        public string? Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged();
            }
        }

        private Teacher? _teacher = null!;
        public Teacher? Teacher
        {
            get => _teacher;
            set
            {
                _teacher = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<Student> Students { get; } = new ObservableCollection<Student>();

        public string? StudentsString => string.Join(", ", Students.Select(s => s.Name)); // New property

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string name = null!)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public Course()
        {
            Students.CollectionChanged += (s, e) => OnPropertyChanged(nameof(StudentsString)); // Update on change
        }
    }
}