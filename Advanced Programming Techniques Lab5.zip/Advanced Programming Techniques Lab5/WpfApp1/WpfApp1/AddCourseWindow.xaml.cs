﻿// AddCourseWindow.xaml.cs
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace WpfApp1
{
    public partial class AddCourseWindow : Window
    {
        private readonly ViewModel _vm;
        private readonly Course _course;
        private Teacher? _oldTeacher;
        private readonly bool _isEdit;
        private readonly ICollectionView _availableView;

        public AddCourseWindow(Course? course = null)
        {
            InitializeComponent();
            _vm = (ViewModel)Application.Current.Resources["VM"];

            if (course == null)
            {
                _course = new Course();
                _isEdit = false;
                SaveButton.Content = "Add";
            }
            else
            {
                _course = course;
                _oldTeacher = course.Teacher;
                _isEdit = true;
                SaveButton.Content = "Save";
                CourseNameTextBox.Text = _course.Name;
            }

            DataContext = _course;

            TeacherComboBox.ItemsSource = _vm.Teachers;
            if (_course.Teacher != null)
                TeacherComboBox.SelectedItem = _course.Teacher;

            _availableView = CollectionViewSource.GetDefaultView(_vm.Students);
            _availableView.Filter = FilterStudents;
            AvailableListView.ItemsSource = _availableView;

            SelectedListView.ItemsSource = _course.Students;
        }

        private bool FilterStudents(object item)
        {
            if (item is not Student student) return false;
            string searchText = SearchTextBox.Text?.Trim() ?? "";
            bool isInCourse = _course.Students.Contains(student);
            bool matchesSearch = string.IsNullOrEmpty(searchText) ||
                student.Name?.Contains(searchText, System.StringComparison.OrdinalIgnoreCase) == true;
            return !isInCourse && matchesSearch;
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            _availableView.Refresh();
        }

        private void AvailableListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (AvailableListView.SelectedItem is Student student)
            {
                _course.Students.Add(student);
                student.Courses?.Add(_course);
                _availableView.Refresh();
            }
        }

        private void RemoveSelected_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedListView.SelectedItem is Student student)
            {
                _course.Students.Remove(student);
                student.Courses?.Remove(_course);
                _availableView.Refresh();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(CourseNameTextBox.Text) || TeacherComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please provide a course name and select a teacher.");
                return;
            }

            _course.Name = CourseNameTextBox.Text.Trim();
            _course.Teacher = TeacherComboBox.SelectedItem as Teacher;

            if (_course.Teacher != _oldTeacher)
            {
                _oldTeacher?.TaughtCourses.Remove(_course);
                _course.Teacher?.TaughtCourses.Add(_course);
            }

            if (!_isEdit)
            {
                _vm.Courses.Add(_course);
            }

            Close();
        }

        private void PasteStudent_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = ClipboardHelper.CopiedStudent != null;
        }

        private void PasteStudent_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                if (ClipboardHelper.CopiedStudent is Student student && student != null && !_course.Students.Contains(student))
                {
                    _course.Students.Add(student);
                    student.Courses?.Add(_course);
                    _availableView.Refresh();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error pasting student: {ex.Message}");
            }
        }

        private void PasteFromClipboard_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ClipboardHelper.CopiedStudent is Student student && student != null && !_course.Students.Contains(student))
                {
                    _course.Students.Add(student);
                    student.Courses?.Add(_course);
                    _availableView.Refresh();
                    SearchTextBox.Text = ""; // Clear search after paste
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error pasting student: {ex.Message}");
            }
        }
    }
}