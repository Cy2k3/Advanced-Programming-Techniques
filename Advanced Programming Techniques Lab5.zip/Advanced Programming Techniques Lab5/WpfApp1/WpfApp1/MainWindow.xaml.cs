﻿// MainWindow.xaml.cs
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        private readonly ViewModel _vm;

        public MainWindow()
        {
            InitializeComponent();
            _vm = (ViewModel)DataContext;
        }

        private void AddStudent_Click(object sender, RoutedEventArgs e)
        {
            var name = newStudentName.Text?.Trim();
            if (!string.IsNullOrEmpty(name))
            {
                _vm.Students.Add(new Student { Name = name });
                newStudentName.Text = "";
            }
        }

        private void RemoveStudent_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is Student student)
            {
                foreach (var course in student.Courses.ToArray())
                {
                    course.Students.Remove(student);
                }
                _vm.Students.Remove(student);
            }
        }

        private void AddTeacher_Click(object sender, RoutedEventArgs e)
        {
            var name = newTeacherName.Text?.Trim();
            if (!string.IsNullOrEmpty(name))
            {
                _vm.Teachers.Add(new Teacher { Name = name });
                newTeacherName.Text = "";
            }
        }

        private void RemoveTeacher_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is Teacher teacher)
            {
                foreach (var course in teacher.TaughtCourses.ToArray())
                {
                    course.Teacher = null;
                }
                _vm.Teachers.Remove(teacher);
            }
        }

        private void AddCourse_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddCourseWindow();
            window.ShowDialog();
        }

        private void CoursesList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (sender is ListView listView && listView.SelectedItem is Course course)
            {
                var window = new AddCourseWindow(course);
                window.ShowDialog();
            }
        }

        private void RemoveCourse_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is Course course)
            {
                course.Teacher?.TaughtCourses.Remove(course);
                foreach (var student in course.Students.ToArray())
                {
                    student.Courses.Remove(course);
                }
                _vm.Courses.Remove(course);
            }
        }

        private void CopyStudent_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = StudentsListView.SelectedItem != null;
        }

        private void CopyStudent_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (StudentsListView.SelectedItem is Student student)
            {
                ClipboardHelper.CopiedStudent = student;
            }
        }

        private void StudentsListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Intentionally empty to prevent removal on selection
        }
    }
}