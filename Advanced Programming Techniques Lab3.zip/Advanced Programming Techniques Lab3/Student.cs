﻿using System;

public class Class1
{
	public Class1()
	{
	}
}
public class Student
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int Age { get; set; }

    public override string ToString() => $"Student {{ Id = {Id}, Name = {Name}, Age = {Age} }}";
}