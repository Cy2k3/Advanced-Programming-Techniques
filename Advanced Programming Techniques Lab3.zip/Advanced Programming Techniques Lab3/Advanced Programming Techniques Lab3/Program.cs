﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace Advanced_Programming_Techniques_Lab3
{
    class Program
    {
        static void Main(string[] args)
        {
            using var db = new MyDatabaseContext();

            // Ensure database file & migrations are applied through Package Manager Console:
            // Install-Package Microsoft.EntityFrameworkCore.Sqlite
            // Install-Package Microsoft.EntityFrameworkCore.Tools
            // Add-Migration InitialCreate
            // Update-Database
            //
            // For development convenience here we will ensure DB is created:
            db.Database.EnsureCreated();

            // Clear existing data so repeated runs don't accumulate (lab requirement)
            foreach (var s in db.Students.ToList()) db.Students.Remove(s);
            foreach (var t in db.Teachers.ToList()) db.Teachers.Remove(t);
            foreach (var c in db.Classes.ToList()) db.Classes.Remove(c);
            db.SaveChanges();

            // Add sample students
            var s1 = new Student { FirstName = "Alice", LastName = "Smith" };
            var s2 = new Student { FirstName = "Bob", LastName = "Jones" };
            db.Students.AddRange(s1, s2);

            // Add classes
            var math = new Class { Name = "Math" };
            var cs = new Class { Name = "Computer Science" };
            db.Classes.AddRange(math, cs);

            db.SaveChanges();

            // Add teachers and link one-to-one (teacher -> class)
            var t1 = new Teacher { Name = "Dr. Brown" };
            db.Teachers.Add(t1);
            db.SaveChanges();

            // Assign teacher to class
            math.TeacherId = t1.Id;
            math.Teacher = t1;
            t1.Classes.Add(math);
            db.SaveChanges();

            // Many-to-many: enroll students into classes
            math.Students.Add(s1);
            math.Students.Add(s2);
            cs.Students.Add(s2); // Bob in CS too
            db.SaveChanges();

            // Print results
            Console.WriteLine("Students:");
            foreach (var st in db.Students.ToList()) Console.WriteLine(st);

            Console.WriteLine("\nClasses:");
            foreach (var cl in db.Classes.Include(c => c.Teacher).Include(c => c.Students).ToList())
            {
                Console.WriteLine(cl);
                Console.WriteLine("  Students:");
                foreach (var st in cl.Students) Console.WriteLine("   - " + st);
            }

            Console.WriteLine("\nTeachers:");
            foreach (var tch in db.Teachers.Include(t => t.Classes).ToList())
            {
                Console.WriteLine(tch);
                Console.WriteLine("  Classes:");
                foreach (var c in tch.Classes) Console.WriteLine("   - " + c.Name);
            }
        }
    }
}
