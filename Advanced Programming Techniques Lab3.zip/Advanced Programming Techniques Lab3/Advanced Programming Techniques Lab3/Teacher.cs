﻿using System.Collections.Generic;

namespace Advanced_Programming_Techniques_Lab3
{
    public class Teacher
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;

        public List<Class> Classes { get; } = new();

        public override string ToString() => $"Teacher {{ Id = {Id}, Name = {Name}, ClassesCount = {Classes?.Count ?? 0} }}";
    }
}
