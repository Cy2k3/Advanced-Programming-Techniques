﻿using System.Collections.Generic;

namespace Advanced_Programming_Techniques_Lab3
{
    public class Student
    {
        public int Id { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;

        public List<Class> Classes { get; } = new();

        public override string ToString() => $"Student {{ Id = {Id}, FirstName = {FirstName}, LastName = {LastName} }}";
    }
}
