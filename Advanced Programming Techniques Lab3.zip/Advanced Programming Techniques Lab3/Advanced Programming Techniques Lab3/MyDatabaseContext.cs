﻿using Microsoft.EntityFrameworkCore;
using System;

namespace Advanced_Programming_Techniques_Lab3
{
    public class MyDatabaseContext : DbContext
    {
        public string DbPath { get; }

        public MyDatabaseContext()
        {
            var folder = Environment.SpecialFolder.LocalApplicationData;
            var path = Environment.GetFolderPath(folder);
            DbPath = System.IO.Path.Join(path, "lab3.db");
        }

        // DbSets
        public DbSet<Student> Students { get; set; } = null!;
        public DbSet<Class> Classes { get; set; } = null!;
        public DbSet<Teacher> Teachers { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder options)
            => options.UseSqlite($"Data Source={DbPath}");

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Many-to-many Student <-> Class
            modelBuilder.Entity<Student>()
                        .HasMany(s => s.Classes)
                        .WithMany(c => c.Students);

            // One-to-many Teacher -> Class
            modelBuilder.Entity<Teacher>()
                        .HasMany(t => t.Classes)
                        .WithOne(c => c.Teacher)
                        .HasForeignKey(c => c.TeacherId)
                        .OnDelete(DeleteBehavior.SetNull);
        }
    }
}
