﻿using System.Collections.Generic;

namespace Advanced_Programming_Techniques_Lab3
{
    public class Class
    {
        public int Id { get; set; }

        // Name is required logically, but keep settable for EF and easier initialization.
        public string Name { get; set; } = string.Empty;

        // Foreign key (nullable: a class might not have a teacher yet)
        public int? TeacherId { get; set; }

        // Navigation property (nullable until EF loads it)
        public Teacher? Teacher { get; set; }

        // Many-to-many with students. Initialize to avoid NRE.
        public List<Student> Students { get; } = new();

        public override string ToString()
        {
            var teacherName = Teacher?.Name ?? "null";
            return $"Class {{ Id = {Id}, Name = {Name}, TeacherId = {TeacherId}, TeacherName = {teacherName}, StudentsCount = {Students?.Count ?? 0} }}";
        }
    }
}
