﻿public class Teacher
{
    public int Id { get; set; }
    public string Name { get; set; }
    public Class Class { get; set; } 
    public ICollection<Class> Classes { get; set; } 

    public override string ToString() => $"Teacher {{ Id = {Id}, Name = {Name}, Class = {Class} }}";
}