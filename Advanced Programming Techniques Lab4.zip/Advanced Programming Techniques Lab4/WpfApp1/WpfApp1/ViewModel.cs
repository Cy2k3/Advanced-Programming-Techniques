﻿using System.Collections.ObjectModel;

namespace WpfApp
{
    public class ViewModel
    {
        public ObservableCollection<Student> Students { get; } = new ObservableCollection<Student>();
        public ObservableCollection<Teacher> Teachers { get; } = new ObservableCollection<Teacher>();
        public ObservableCollection<Course> Courses { get; } = new ObservableCollection<Course>();
    }
}