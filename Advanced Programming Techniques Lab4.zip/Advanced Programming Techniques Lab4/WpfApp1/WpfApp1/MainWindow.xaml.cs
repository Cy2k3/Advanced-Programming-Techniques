﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Linq;

namespace WpfApp
{
    public partial class MainWindow : Window
    {
        private ViewModel _vm;

        public MainWindow()
        {
            InitializeComponent();
            _vm = (ViewModel)DataContext;
        }

        private void AddStudent_Click(object sender, RoutedEventArgs e)
        {
            var name = newStudentName.Text.Trim();
            if (!string.IsNullOrEmpty(name))
            {
                _vm.Students.Add(new Student { Name = name });
                newStudentName.Text = "";
            }
        }

        private void RemoveStudent_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is Student student)
            {
                // Remove from all courses
                foreach (var course in student.Courses.ToArray())
                {
                    course.Students.Remove(student);
                }
                _vm.Students.Remove(student);
            }
        }

        private void AddTeacher_Click(object sender, RoutedEventArgs e)
        {
            var name = newTeacherName.Text.Trim();
            if (!string.IsNullOrEmpty(name))
            {
                _vm.Teachers.Add(new Teacher { Name = name });
                newTeacherName.Text = "";
            }
        }

        private void RemoveTeacher_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is Teacher teacher)
            {
                // Remove from all courses
                foreach (var course in teacher.TaughtCourses.ToArray())
                {
                    course.Teacher = null;
                }
                _vm.Teachers.Remove(teacher);
            }
        }

        private void AddCourse_Click(object sender, RoutedEventArgs e)
        {
            var window = new AddCourseWindow();
            window.ShowDialog();
            // Refresh lists if needed, but bindings handle it
        }

        private void CoursesList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (CoursesListView.SelectedItem is Course course)
            {
                var window = new AddCourseWindow(course);
                window.ShowDialog();
            }
        }

        private void RemoveCourse_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.Tag is Course course)
            {
                // Clean up relationships
                course.Teacher?.TaughtCourses.Remove(course);
                foreach (var student in course.Students.ToArray())
                {
                    student.Courses.Remove(course);
                }
                _vm.Courses.Remove(course);
            }
        }
    }
}