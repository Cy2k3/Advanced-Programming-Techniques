﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Linq;
using System.Collections;

namespace WpfApp
{
    public partial class AddCourseWindow : Window
    {
        private readonly ViewModel _vm;
        private Course _course;
        private Teacher _oldTeacher;
        private bool _isEdit;

        public AddCourseWindow(Course course = null)
        {
            InitializeComponent();
            _vm = (ViewModel)Application.Current.Resources["VM"];

            if (course == null)
            {
                _course = new Course();
                _isEdit = false;
                SaveButton.Content = "Add";
            }
            else
            {
                _course = course;
                _oldTeacher = course.Teacher;
                _isEdit = true;
                SaveButton.Content = "Save";
                CourseNameTextBox.Text = _course.Name;
            }

            TeacherComboBox.ItemsSource = _vm.Teachers;
            if (_course.Teacher != null)
                TeacherComboBox.SelectedItem = _course.Teacher;

            UpdateLists();
        }

        private void UpdateLists()
        {
            AvailableListView.ItemsSource = _vm.Students.Where(s => !_course.Students.Contains(s)).ToList();
            SelectedListView.ItemsSource = _course.Students;
        }

        private void AvailableListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (AvailableListView.SelectedItem is Student student)
            {
                _course.Students.Add(student);
                student.Courses.Add(_course);
                UpdateLists();
            }
        }

        private void RemoveStudent_Click(object sender, RoutedEventArgs e)
        {
            if (SelectedListView.SelectedItem is Student student)
            {
                _course.Students.Remove(student);
                student.Courses.Remove(_course);
                UpdateLists();
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            _course.Name = CourseNameTextBox.Text.Trim();
            _course.Teacher = TeacherComboBox.SelectedItem as Teacher;

            if (string.IsNullOrEmpty(_course.Name) || _course.Teacher == null)
            {
                MessageBox.Show("Please provide a course name and select a teacher.");
                return;
            }

            // Update teacher courses if changed
            if (_course.Teacher != _oldTeacher)
            {
                _oldTeacher?.TaughtCourses.Remove(_course);
                _course.Teacher.TaughtCourses.Add(_course);
            }

            if (!_isEdit)
            {
                _vm.Courses.Add(_course);
            }

            DialogResult = true;
            Close();
        }
    }
}