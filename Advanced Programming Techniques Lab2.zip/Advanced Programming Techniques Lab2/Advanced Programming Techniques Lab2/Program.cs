﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

public class City
{
    public string Name { get; set; }
    public int Population { get; set; }

    public City(string name, int population)
    {
        Name = name;
        Population = population;
    }
}

public class Person
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string City { get; set; }
    public int Height { get; set; }
    public string? Allergies { get; set; }

    public Person(string firstName, string lastName, string city, int height, string? allergies)
    {
        FirstName = firstName;
        LastName = lastName;
        City = city;
        Height = height;
        Allergies = allergies;
    }
}

internal class Program
{
    static void Main(string[] args)
    {
        int[] numbers =
        {
            106, 104, 10, 5, 117, 174, 95, 61, 74, 145, 77, 95, 72, 59, 114, 95, 61, 116, 106, 66, 75, 85, 104,
            62, 76, 87, 70, 17, 141, 39, 199, 91, 37, 139, 88, 84, 15, 166, 118, 54, 42, 123, 53, 183, 95, 101,
            112, 26, 41, 135, 70, 48, 89, 69, 109, 93, 110, 153, 178, 117, 5
        };

        City[] cities =
        {
            new City("Toronto", 100200),
            new City("Hamilton", 80923),
            new City("Ancaster", 4039),
            new City("Brantford", 500890),
        };

        Person[] persons =
        {
            new Person("Don", "Wiggum", "Hamilton", 189, null),
            new Person("Anthony", "Maxwell", "Oakville", 92, null),
            new Person("James", "Sullivan", "Delhi", 139, null),
            new Person("Anne", "Marlowe", "Pickering", 165, "Peanut Oil"),
            new Person("Kelly", "Hamilton", "Stoner", 84, null),
            new Person("Charles", "Andonuts", "Hamilton", 62, null),
            new Person("Temple", "Russert", "Hamilton", 166, "Sulphur"),
            new Person("Don", "Edwards", "Hamilton", 215, null),
            new Person("Alice", "Donovan", "Hamilton", 167, null),
            new Person("Stone", "Cutting", "Hamilton", 110, null),
            new Person("Neil", "Allan", "Cambridge", 203, null),
            new Person("Croos", "Gordon", "Ancaster", 125, null),
            new Person("Phoebe", "Bigelow", "Thunder", 183, null),
            new Person("Harry", "Kuramitsu", "Hamilton", 210, null)
        };

        // Task 1a: Select numbers greater than 80
        var querySyntax1a = from n in numbers where n > 80 select n;
        var methodSyntax1a = numbers.Where(n => n > 80);
        Console.WriteLine("Numbers > 80 (Query Syntax): " + string.Join(", ", querySyntax1a));
        Console.WriteLine("Numbers > 80 (Method Syntax): " + string.Join(", ", methodSyntax1a));

        // Task 1b: Order numbers descending
        var querySyntax1b = from n in numbers orderby n descending select n;
        var methodSyntax1b = numbers.OrderByDescending(n => n);
        Console.WriteLine("Numbers (Descending, Query Syntax): " + string.Join(", ", querySyntax1b));
        Console.WriteLine("Numbers (Descending, Method Syntax): " + string.Join(", ", methodSyntax1b));

        // Task 1c: Transform numbers into "Have number #n"
        var querySyntax1c = from n in numbers select $"Have number #{n}";
        var methodSyntax1c = numbers.Select(n => $"Have number #{n}");
        Console.WriteLine("Transformed (Query Syntax): " + string.Join(", ", querySyntax1c));
        Console.WriteLine("Transformed (Method Syntax): " + string.Join(", ", methodSyntax1c));

        // Task 1d: Count numbers between 70 and 100
        var query1d = from n in numbers where n < 100 && n > 70 select n;
        int count1d = query1d.Count();
        Console.WriteLine("Count of numbers between 70 and 100: " + count1d);

        // Task 2a: Select persons with particular height (function)
        Func<int, IEnumerable<Person>> selectByHeight = height =>
            from p in persons where p.Height == height select p;
        var result2a = selectByHeight(165);
        Console.WriteLine("Persons with height 165 (Query Syntax): " + string.Join(", ", result2a.Select(p => $"{p.FirstName} {p.LastName}")));
        var methodResult2a = persons.Where(p => p.Height == 165);
        Console.WriteLine("Persons with height 165 (Method Syntax): " + string.Join(", ", methodResult2a.Select(p => $"{p.FirstName} {p.LastName}")));

        // Task 2b: Transform name and last name into J. Doe format
        var querySyntax2b = from p in persons select $"{p.FirstName[0]}. {p.LastName}";
        var methodSyntax2b = persons.Select(p => $"{p.FirstName[0]}. {p.LastName}");
        Console.WriteLine("Names (Query Syntax): " + string.Join(", ", querySyntax2b));
        Console.WriteLine("Names (Method Syntax): " + string.Join(", ", methodSyntax2b));

        // Task 2c: Select distinct allergies
        var querySyntax2c = (from p in persons where p.Allergies != null select p.Allergies.Split(',')).SelectMany(x => x).Distinct();
        var methodSyntax2c = persons.Where(p => p.Allergies != null).SelectMany(p => p.Allergies.Split(',')).Distinct();
        Console.WriteLine("Distinct Allergies (Query Syntax): " + string.Join(", ", querySyntax2c));
        Console.WriteLine("Distinct Allergies (Method Syntax): " + string.Join(", ", methodSyntax2c));

        // Task 2d: Count cities starting with "H"
        int count2d = cities.Count(c => c.Name.StartsWith("H"));
        Console.WriteLine("Number of cities starting with 'H': " + count2d);

        // Task 2e: Join persons and cities, select from cities > 100000
        var query2e = from c in cities
                      join p in persons on c.Name equals p.City
                      where c.Population > 100000
                      select p;
        var methodQuery2e = cities.Join(persons, c => c.Name, p => p.City, (c, p) => p).Where(p => p.City == "Toronto");
        Console.WriteLine("Persons from cities > 100000 (Query Syntax): " + string.Join(", ", query2e.Select(p => $"{p.FirstName} {p.LastName}")));
        Console.WriteLine("Persons from cities > 100000 (Method Syntax): " + string.Join(", ", methodQuery2e.Select(p => $"{p.FirstName} {p.LastName}")));

        // Task 2f: Manually add three city names and select persons
        string[] specificCities = { "Hamilton", "Ancaster", "Toronto" };
        var inCities = from p in persons where specificCities.Contains(p.City) select p;
        var notInCities = from p in persons where !specificCities.Contains(p.City) select p;
        Console.WriteLine("Persons in specific cities: " + string.Join(", ", inCities.Select(p => $"{p.FirstName} {p.LastName}")));
        Console.WriteLine("Persons not in specific cities: " + string.Join(", ", notInCities.Select(p => $"{p.FirstName} {p.LastName}")));

        // Task 3: Convert persons list to XML
        XElement xmlPersons = new XElement("Persons",
            from p in persons
            select new XElement("Person",
                new XElement("FirstName", p.FirstName),
                new XElement("LastName", p.LastName),
                new XElement("City", p.City),
                new XElement("Height", p.Height),
                p.Allergies != null ? new XElement("Allergies", p.Allergies) : null
            )
        );
        Console.WriteLine("XML Representation:\n" + xmlPersons.ToString());
    }
}