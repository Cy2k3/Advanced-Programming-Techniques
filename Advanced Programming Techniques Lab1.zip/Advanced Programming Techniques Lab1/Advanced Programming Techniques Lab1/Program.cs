﻿using System;

public delegate void OnResult(string result);
public delegate string CommandReader();

interface Operation
{
    void Perform();
    event OnResult ResultEvent;
}

class ExitOperation : Operation
{
    public event OnResult ResultEvent;
    private Action exitAction;

    public ExitOperation(Action exitAction)
    {
        this.exitAction = exitAction;
        ResultEvent += delegate { };
    }

    public void Perform()
    {
        exitAction?.Invoke();
        ResultEvent?.Invoke("Program end");
    }
}

class SumOperation : Operation
{
    public event OnResult ResultEvent;
    private int term1, term2;

    public SumOperation(int term1, int term2)
    {
        this.term1 = term1;
        this.term2 = term2;
        ResultEvent += delegate { };
    }

    public void Perform()
    {
        int result = term1 + term2;
        ResultEvent?.Invoke($"Result: {result}");
    }
}

class DifferenceOperation : Operation
{
    public event OnResult ResultEvent;
    private int term1, term2;

    public DifferenceOperation(int term1, int term2)
    {
        this.term1 = term1;
        this.term2 = term2;
        ResultEvent += delegate { };
    }

    public void Perform()
    {
        int result = term1 - term2;
        ResultEvent?.Invoke($"Result: {result}");
    }
}

internal class Program
{
    static bool runs = true;

    private static void Main(string[] args)
    {
        var operations = new System.Collections.Generic.Dictionary<string, Func<string, Operation>>
        {
            { "exit", cmd => new ExitOperation(() => runs = false) },
            { "sum", cmd =>
                {
                    var parts = cmd.Split(' ');
                    if (parts.Length == 3 && int.TryParse(parts[1], out int term1) && int.TryParse(parts[2], out int term2))
                        return new SumOperation(term1, term2);
                    return null;
                }
            },
            { "dif", cmd =>
                {
                    var parts = cmd.Split(' ');
                    if (parts.Length == 3 && int.TryParse(parts[1], out int term1) && int.TryParse(parts[2], out int term2))
                        return new DifferenceOperation(term1, term2);
                    return null;
                }
            }
        };

        CommandReader reader = () => Console.ReadLine();

        Console.WriteLine("Enter a command (e.g., 'sum 5 3', 'dif 10 4', or 'exit') or press Enter to continue...");

        while (runs)
        {
            string? command = reader();
            if (string.IsNullOrEmpty(command))
            {
                continue;
            }
            string[] parts = command.Split(' ', 2);
            string cmd = parts[0].ToLower();
            if (operations.ContainsKey(cmd))
            {
                Operation operation = operations[cmd](command);
                if (operation != null)
                {
                    operation.ResultEvent += Console.WriteLine;
                    operation.Perform();
                    operation.ResultEvent -= Console.WriteLine;
                }
                else
                {
                    Console.WriteLine("Invalid number format. Use: command number1 number2 (e.g., 'sum 5 3').");
                }
            }
            else
            {
                Console.WriteLine("Unknown command");
            }
            if (runs) Console.WriteLine("Enter a command (e.g., 'sum 5 3', 'dif 10 4', or 'exit') or press Enter to continue...");
        }
    }
}